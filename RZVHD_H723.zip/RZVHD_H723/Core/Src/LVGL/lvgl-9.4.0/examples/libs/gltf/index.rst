Open a GLTF from a file and make it spin forever like a platter
---------------------------------------------------------------

.. lv_example:: libs/gltf/lv_example_gltf_1
  :language: c


Open a GLTF from a file and iterate through each camera
-------------------------------------------------------

.. lv_example:: libs/gltf/lv_example_gltf_2
  :language: c
