Loads a video from the internet using the gstreamer widget
----------------------------------------------------------

.. lv_example:: libs/gstreamer/lv_example_gstreamer_1
  :language: c
