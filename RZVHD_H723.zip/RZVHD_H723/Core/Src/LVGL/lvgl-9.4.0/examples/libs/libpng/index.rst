Open a PNG image from file and variable
---------------------------------------

.. lv_example:: libs/libpng/lv_example_libpng_1
  :language: c

