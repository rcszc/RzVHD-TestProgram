Open a font with Tiny TTF from data array
------------------------------------------

.. lv_example:: libs/tiny_ttf/lv_example_tiny_ttf_1
  :language: c


Load a font with Tiny_TTF from file
-----------------------------------

.. lv_example:: libs/tiny_ttf/lv_example_tiny_ttf_2
  :language: c

Change font size with Tiny_TTF
------------------------------

.. lv_example:: libs/tiny_ttf/lv_example_tiny_ttf_3
  :language: c
