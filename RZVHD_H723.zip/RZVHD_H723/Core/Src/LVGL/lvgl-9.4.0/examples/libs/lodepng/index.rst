Open a PNG image from file and variable
---------------------------------------

.. lv_example:: libs/lodepng/lv_example_lodepng_1
  :language: c

