Load and render SVG data
------------------------

.. lv_example:: libs/svg/lv_example_svg_1
  :language: c

Load and render SVG data from a file
------------------------------------

.. lv_example:: libs/svg/lv_example_svg_2
  :language: c

Load and render SVG data in a draw event
----------------------------------------

.. lv_example:: libs/svg/lv_example_svg_3
  :language: c
