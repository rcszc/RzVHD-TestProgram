Simple translation example
---------------------------

.. lv_example:: others/translation/lv_example_translation_1
  :language: c

Dynamic language selection
--------------------------

.. lv_example:: others/translation/lv_example_translation_2
  :language: c


