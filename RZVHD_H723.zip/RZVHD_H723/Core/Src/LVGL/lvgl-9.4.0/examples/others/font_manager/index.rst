
Create FreeType Font
--------------------

.. lv_example:: others/font_manager/lv_example_font_manager_1
  :language: c

Create Font Family
------------------

.. lv_example:: others/font_manager/lv_example_font_manager_2
  :language: c

Create Custom Image Font
------------------------

.. lv_example:: others/font_manager/lv_example_font_manager_3
  :language: c
