
Simple Buttons
--------------

.. lv_example:: widgets/button/lv_example_button_1
  :language: c


Styling buttons
---------------

.. lv_example:: widgets/button/lv_example_button_2
  :language: c

Gummy button
------------

.. lv_example:: widgets/button/lv_example_button_3
  :language: c

