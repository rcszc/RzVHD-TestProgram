
Image from variable and symbol
------------------------------

.. lv_example:: widgets/image/lv_example_image_1
  :language: c


Image recoloring
----------------

.. lv_example:: widgets/image/lv_example_image_2
  :language: c


Rotate and zoom
---------------

.. lv_example:: widgets/image/lv_example_image_3
  :language: c

Image offset and styling
------------------------

.. lv_example:: widgets/image/lv_example_image_4
  :language: c


