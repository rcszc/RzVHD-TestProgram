
Calendar with header
--------------------

.. lv_example:: widgets/calendar/lv_example_calendar_1
  :language: c

Chinese calendar
-------------------------------------

.. lv_example:: widgets/calendar/lv_example_calendar_2
  :language: c
