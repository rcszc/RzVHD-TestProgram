Drawing on the Canvas and rotate
--------------------------------

.. lv_example:: widgets/canvas/lv_example_canvas_1
  :language: c

Transparent Canvas with chroma keying
-------------------------------------

.. lv_example:: widgets/canvas/lv_example_canvas_2
  :language: c


Draw a rectangle to the canvas
------------------------------

.. lv_example:: widgets/canvas/lv_example_canvas_3
  :language: c


Draw a label to the canvas
--------------------------

.. lv_example:: widgets/canvas/lv_example_canvas_4
  :language: c


Draw an arc to the canvas
-------------------------

.. lv_example:: widgets/canvas/lv_example_canvas_5
  :language: c


Draw an image to the canvas
---------------------------

.. lv_example:: widgets/canvas/lv_example_canvas_6
  :language: c


Draw a line to the canvas
-------------------------

.. lv_example:: widgets/canvas/lv_example_canvas_7
  :language: c

Draw a vector graphic to the canvas
-----------------------------------

.. lv_example:: widgets/canvas/lv_example_canvas_8
  :language: c

Draw a triangle to the canvas
-----------------------------

.. lv_example:: widgets/canvas/lv_example_canvas_9
  :language: c

Draw Fancy Letter Effects
-------------------------

.. lv_example:: widgets/canvas/lv_example_canvas_10
  :language: c


Draw Fancy Letter Effects 2
---------------------------
.. lv_example:: widgets/canvas/lv_example_canvas_11
  :language: c
