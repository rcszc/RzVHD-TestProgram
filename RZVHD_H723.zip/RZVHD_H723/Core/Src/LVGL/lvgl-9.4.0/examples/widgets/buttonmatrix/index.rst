
Simple Button matrix
--------------------

.. lv_example:: widgets/buttonmatrix/lv_example_buttonmatrix_1
  :language: c


Custom buttons
--------------

.. lv_example:: widgets/buttonmatrix/lv_example_buttonmatrix_2
  :language: c


Pagination
----------

.. lv_example:: widgets/buttonmatrix/lv_example_buttonmatrix_3
  :language: c


