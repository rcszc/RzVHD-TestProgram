
Simple Message box
------------------

.. lv_example:: widgets/msgbox/lv_example_msgbox_1
  :language: c

Scrolling and styled Message box
--------------------------------

.. lv_example:: widgets/msgbox/lv_example_msgbox_2
  :language: c


