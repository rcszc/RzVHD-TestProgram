
Simple Switch
-------------

.. lv_example:: widgets/switch/lv_example_switch_1
  :language: c


Switch Orientation
-------------------

.. lv_example:: widgets/switch/lv_example_switch_2
  :language: c

