Simple Arc Label
----------------

.. lv_example:: widgets/arclabel/lv_example_arclabel_1
    :language: c
    :description: A simple example to demonstrate the use of an arc label.
