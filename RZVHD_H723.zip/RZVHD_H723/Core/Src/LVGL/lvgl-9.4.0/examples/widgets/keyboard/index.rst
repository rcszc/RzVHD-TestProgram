
Keyboard with text area
-----------------------

.. lv_example:: widgets/keyboard/lv_example_keyboard_1
  :language: c


Keyboard with custom map
------------------------

.. lv_example:: widgets/keyboard/lv_example_keyboard_2
  :language: c


Keyboard with drawing
---------------------

.. lv_example:: widgets/keyboard/lv_example_keyboard_3
  :language: c

