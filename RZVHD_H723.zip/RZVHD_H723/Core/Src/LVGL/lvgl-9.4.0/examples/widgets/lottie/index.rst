Load a Lottie animation from an array
-------------------------------------

.. lv_example:: widgets/lottie/lv_example_lottie_1
  :language: c

Load a Lottie animation from file
---------------------------------

.. lv_example:: widgets/lottie/lv_example_lottie_2
  :language: c
