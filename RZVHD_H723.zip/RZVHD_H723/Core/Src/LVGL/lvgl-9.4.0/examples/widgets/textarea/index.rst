
Simple Text area
----------------

.. lv_example:: widgets/textarea/lv_example_textarea_1
  :language: c


Text area with password field
-----------------------------

.. lv_example:: widgets/textarea/lv_example_textarea_2
  :language: c

Text auto-formatting
--------------------

.. lv_example:: widgets/textarea/lv_example_textarea_3
  :language: c

Text area cursor styling
------------------------

.. lv_example:: widgets/textarea/lv_example_textarea_4
  :language: c
