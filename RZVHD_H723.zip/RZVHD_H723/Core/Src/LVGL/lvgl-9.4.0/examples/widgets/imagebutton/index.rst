
Simple Image button
-------------------

.. lv_example:: widgets/imagebutton/lv_example_imagebutton_1
  :language: c

