/*
 * rz_st7796_fmc_driver_mpu.c
 *
 *  Created on: Feb 2, 2026
 *      Author: RCSZ
 */
#include <stdlib.h>
#include "rz_st7796_fmc_driver.h"

#ifdef ENABLE_FMC_ST7796DRV
// ENABLE I/D CACHE => ENABLE MPU AND CONFIG
// DEFAULT: SIZE 1-BANK
void STLCD_MEMORY_MPU(size_t base_addr) {
  HAL_MPU_Disable();
  MPU_Region_InitTypeDef MPU_InitStruct = { 0 };

  MPU_InitStruct.Enable = MPU_REGION_ENABLE;    // 开启该保护区
  MPU_InitStruct.Number = MPU_REGION_NUMBER0;   // 设置保护区域
  MPU_InitStruct.BaseAddress = base_addr;       // 设置基地址
  MPU_InitStruct.Size = MPU_REGION_SIZE_64MB;   // 设置保护区域大小
  MPU_InitStruct.SubRegionDisable = 0x00;       // 禁止子区

  MPU_InitStruct.TypeExtField     = MPU_TEX_LEVEL0;
  MPU_InitStruct.AccessPermission = MPU_REGION_FULL_ACCESS;
  MPU_InitStruct.DisableExec      = MPU_INSTRUCTION_ACCESS_ENABLE;
  MPU_InitStruct.IsShareable      = MPU_ACCESS_NOT_SHAREABLE;
  MPU_InitStruct.IsCacheable      = MPU_ACCESS_NOT_CACHEABLE;
  MPU_InitStruct.IsBufferable     = MPU_ACCESS_BUFFERABLE;

  HAL_MPU_ConfigRegion(&MPU_InitStruct);
  HAL_MPU_Enable(MPU_HFNMI_PRIVDEF);
}
#endif

