/*
 * rz_st7796_fmc_driver.h
 *
 *  Created on: Feb 2, 2026
 *      Author: RCSZ
 */
#ifndef SRC_RZ_ST7796_FMC_DRIVER_H_
#define SRC_RZ_ST7796_FMC_DRIVER_H_
#include "main.h"
#ifdef ENABLE_FMC_ST7796DRV

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>

// 0:竖屏, 1竖屏(反), 2:横屏, 3:横屏(反)
#define LCD_MODE_CONFIG 2
// LCD RENDER SIZE PX W-H
#define LCD_SIZE_X 480
#define LCD_SIZE_Y 320

#define LCD_COLOR_INVERT 0

// ST7796 REST 引脚配置
#define LCD_REST_LOW() HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_RESET)
#define LCD_REST_HIG() HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET)
// ST7796 BL(background) 引脚配置
#define LCD_BL_LOW() HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, GPIO_PIN_RESET)
#define LCD_BL_HIG() HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, GPIO_PIN_SET)

void STLCD_WRITE_DAT1B(uint8_t  dat);
void STLCD_WRITE_DAT2B(uint16_t dat);
void STLCD_WRITE_REG  (uint8_t  dat);

#define LCD_HIGH_MEMCPY 0

void STLCD_WRITE_VECTOR08(const uint8_t*  dat, size_t len);
void STLCD_WRITE_VECTOR16(const uint16_t* dat, size_t len);

uint32_t STLCD_GET_DATAPTR();

void STLCD_SET_COORD(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2);

#define RZ_MPU_ENABLE   1
#define RZ_MPU_BASEADDR 0x60000000

void STLCD_MEMORY_MPU(size_t base_addr);

// 初始化配置 ST7796 REG FILL CONFIG
void RZSystemInitLCD(void);
#endif
#endif /* SRC_RZGUI_LCD_RZ_ST7796_FMC_DRIVER_H_ */
