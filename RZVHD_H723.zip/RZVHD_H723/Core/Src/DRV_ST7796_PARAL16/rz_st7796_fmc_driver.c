/*
 * rz_st7796_fmc_driver.c
 *
 *  Created on: Feb 2, 2026
 *      Author: RCSZ
 */
#include <stdlib.h>
#include "rz_st7796_fmc_driver.h"

#define FMC_LCD_BANK   FMC_NORSRAM_BANK1
#define FMC_LCD_SELECT 16

#define FMC_LCD_BASE_ADDR (0x60000000U | (FMC_LCD_BANK << 25))
#define FMC_LCD_REGI_ADDR (FMC_LCD_BASE_ADDR)
#define FMC_LCD_DATA_ADDR (FMC_LCD_BASE_ADDR + (1 << (FMC_LCD_SELECT + 1)))

#define LCD_PARALLEL08B_REG ((volatile uint8_t*)FMC_LCD_REGI_ADDR)
#define LCD_PARALLEL08B_DAT ((volatile uint8_t*)FMC_LCD_DATA_ADDR)

#define LCD_PARALLEL16B_REG ((volatile uint16_t*)FMC_LCD_REGI_ADDR)
#define LCD_PARALLEL16B_DAT ((volatile uint16_t*)FMC_LCD_DATA_ADDR)

#ifdef ENABLE_FMC_ST7796DRV

extern DMA_HandleTypeDef hdma_dma_generator0;
// fmc write data: 8bits [1byte]
void STLCD_WRITE_DAT1B(uint8_t dat)  { *LCD_PARALLEL08B_DAT = dat; }
// fmc write data: 16bits [2byte]
void STLCD_WRITE_DAT2B(uint16_t dat) { *LCD_PARALLEL16B_DAT = dat; }
// fmc write register: 8bits [1byte]
void STLCD_WRITE_REG(uint8_t dat)    { *LCD_PARALLEL08B_REG = dat; }
// fmc block(vector) write 8-bit
void STLCD_WRITE_VECTOR08(const uint8_t* dat, size_t len) {
#if (LCD_HIGH_MEMCPY == 1)
	volatile uint16_t *GraphMemPtr = LCD_PARALLEL16B_DAT;
	// ...
#else
#pragma GCC unroll 16
	for (size_t i = 0; i < len; i += 2)
		*LCD_PARALLEL16B_DAT = (uint16_t)(dat[i] | (dat[i + 1] << 8));
#endif
}
// fmc block(vector) write 16-bit
void STLCD_WRITE_VECTOR16(const uint16_t* dat, size_t len) {
#if (LCD_HIGH_MEMCPY == 1)
	volatile uint16_t *GraphMemPtr = LCD_PARALLEL16B_DAT;
	// ...
#else
#pragma GCC unroll 16
	for (size_t i = 0; i < len; ++i)
		*LCD_PARALLEL16B_DAT = dat[i];
#endif
}

uint32_t STLCD_GET_DATAPTR() {
	return (uint32_t)LCD_PARALLEL16B_DAT;
}

// setting lcd coord x,y address reg.
void STLCD_SET_COORD(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2)
{
	STLCD_WRITE_REG(0x2a); // column address

	STLCD_WRITE_DAT1B(x1 >> 8);
	STLCD_WRITE_DAT1B(x1 & 0xff);
	STLCD_WRITE_DAT1B(x2 >> 8);
	STLCD_WRITE_DAT1B(x2 & 0xff);

	STLCD_WRITE_REG(0x2b); // row address

	STLCD_WRITE_DAT1B(y1 >> 8);
	STLCD_WRITE_DAT1B(y1 & 0xff);
	STLCD_WRITE_DAT1B(y2 >> 8);
	STLCD_WRITE_DAT1B(y2 & 0xff);

	STLCD_WRITE_REG(0x2c); // register write
}

void RZSystemInitLCD(void)
{
#if (RZ_MPU_ENABLE == 1)
	STLCD_MEMORY_MPU(RZ_MPU_BASEADDR);
	HAL_Delay(500);
#endif
	LCD_BL_LOW();
	HAL_Delay(100);
	LCD_REST_LOW();
	HAL_Delay(200);
	LCD_REST_HIG();
	HAL_Delay(200);

	STLCD_WRITE_REG(0x11);
	HAL_Delay(200);
	// start initial sequence.
	STLCD_WRITE_REG(0xF0);
	STLCD_WRITE_DAT1B(0xC3);

//	STLCD_WRITE_REG(0xC2);
//	STLCD_WRITE_DAT1B(0x01);

	STLCD_WRITE_REG(0xF0);
	STLCD_WRITE_DAT1B(0x96);

	STLCD_WRITE_REG(0x36);
	STLCD_WRITE_DAT1B(0x28);

	STLCD_WRITE_REG(0x3A);
	STLCD_WRITE_DAT1B(0x55);

	STLCD_WRITE_REG(0xB0);
	STLCD_WRITE_DAT1B(0x80);

	STLCD_WRITE_REG(0xB6);
	STLCD_WRITE_DAT1B(0x00);
	STLCD_WRITE_DAT1B(0x02);

	STLCD_WRITE_REG(0xB5);
	STLCD_WRITE_DAT1B(0x02);
	STLCD_WRITE_DAT1B(0x03);
	STLCD_WRITE_DAT1B(0x00);
	STLCD_WRITE_DAT1B(0x04);

	STLCD_WRITE_REG(0xB1);
	STLCD_WRITE_DAT1B(0x80);
	STLCD_WRITE_DAT1B(0x10);

	STLCD_WRITE_REG(0xB4);
	STLCD_WRITE_DAT1B(0x00);

	STLCD_WRITE_REG(0xB7);
	STLCD_WRITE_DAT1B(0xC6);

	STLCD_WRITE_REG(0xC5);
	STLCD_WRITE_DAT1B(0x24);

	STLCD_WRITE_REG(0xE4);
	STLCD_WRITE_DAT1B(0x31);

	STLCD_WRITE_REG(0xE8);
	STLCD_WRITE_DAT1B(0x40);
	STLCD_WRITE_DAT1B(0x8A);
	STLCD_WRITE_DAT1B(0x00);
	STLCD_WRITE_DAT1B(0x00);
	STLCD_WRITE_DAT1B(0x29);
	STLCD_WRITE_DAT1B(0x19);
	STLCD_WRITE_DAT1B(0xA5);
	STLCD_WRITE_DAT1B(0x33);

	STLCD_WRITE_REG(0xA7);
	// +Gamma
	STLCD_WRITE_REG(0xE0);
	STLCD_WRITE_DAT1B(0xF0);
	STLCD_WRITE_DAT1B(0x09);
	STLCD_WRITE_DAT1B(0x13);
	STLCD_WRITE_DAT1B(0x12);
	STLCD_WRITE_DAT1B(0x12);
	STLCD_WRITE_DAT1B(0x2B);
	STLCD_WRITE_DAT1B(0x3C);
	STLCD_WRITE_DAT1B(0x44);
	STLCD_WRITE_DAT1B(0x4B);
	STLCD_WRITE_DAT1B(0x1B);
	STLCD_WRITE_DAT1B(0x18);
	STLCD_WRITE_DAT1B(0x17);
	STLCD_WRITE_DAT1B(0x1D);
	STLCD_WRITE_DAT1B(0x21);
	// -Gamma
	STLCD_WRITE_REG(0xE1);
	STLCD_WRITE_DAT1B(0xF0);
	STLCD_WRITE_DAT1B(0x09);
	STLCD_WRITE_DAT1B(0x13);
	STLCD_WRITE_DAT1B(0x0C);
	STLCD_WRITE_DAT1B(0x0D);
	STLCD_WRITE_DAT1B(0x27);
	STLCD_WRITE_DAT1B(0x3B);
	STLCD_WRITE_DAT1B(0x44);
	STLCD_WRITE_DAT1B(0x4D);
	STLCD_WRITE_DAT1B(0x0B);
	STLCD_WRITE_DAT1B(0x17);
	STLCD_WRITE_DAT1B(0x17);
	STLCD_WRITE_DAT1B(0x1D);
	STLCD_WRITE_DAT1B(0x21);

	STLCD_WRITE_REG(0x13);
	HAL_Delay(100);

#if (LCD_COLOR_INVERT == 0)
	STLCD_WRITE_REG(0x20);
#else
	STLCD_WRITE_REG(0x21);
#endif

	STLCD_WRITE_REG(0xF0);
	STLCD_WRITE_DAT1B(0xC3);
	STLCD_WRITE_REG(0xF0);
	STLCD_WRITE_DAT1B(0x69);

	STLCD_WRITE_REG(0x36);
	switch(LCD_MODE_CONFIG) {
	case(0): STLCD_WRITE_DAT1B(0x48); break;
	case(1): STLCD_WRITE_DAT1B(0x88); break;
	case(2): STLCD_WRITE_DAT1B(0x28); break;
	case(3): STLCD_WRITE_DAT1B(0xE8); break;
	}
	STLCD_WRITE_REG(0x29);
	HAL_Delay(200);

	LCD_BL_HIG();
}
#endif
